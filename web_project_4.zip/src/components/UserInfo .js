export default class UserInfo {
  constructor(usernameSelector, userJobSelector, profileImageSelector) {
    this._name = document.querySelector(usernameSelector);
    this._about = document.querySelector(userJobSelector);
    this._avatar = document.querySelector(profileImageSelector);
  }
  getUserInfo() {
    this._data = {
      name: this._name.textContent,
      about: this._about.textContent,
      avatar: this._avatar.src,
    };
    return this._data;
  }
  setUserInfo = (newData) => {
    console.log(newData);
    const { name, about, avatar } = newData;
    this._name.textContent = name;
    this._about.textContent = about;
    if (avatar) this._avatar.src = avatar;
    this._data = newData;
    return this._data;
  };
}
