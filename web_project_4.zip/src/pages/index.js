//Imports
import "./index.css";
import { initialCards } from "../scripts/initialCards.js";
import Card from "../components/Card.js";
import FormValidator from "../components/FormValidator.js";
import PopupForm from "../components/PopupForm.js";
import PopupGallery from "../components/PopupGallery.js";
import PopupConfirm from "../components/PopupConfirm";
import Section from "../components/Section.js";
import UserInfo from "../components/UserInfo .js";
import Api from "../components/Api.js";
import {
  settings,
  addButton,
  editButton,
  enlargeImageButton,
  editImageButton,
  galleryWindow,
  addWindow,
  editProfileWindow,
  editProfilePictureWindow,
  largeProfileImageWindow,
  cardContainer,
  cardTemplate,
  addForm,
  editForm,
  editProfilePictureForm,
} from "../scripts/constants.js";
import { loader } from "./loader.js";

const tooltipCheck = (renderedCard) => {
  let tooltip = renderedCard.querySelector(".card__overflow-tooltip");
  let text = renderedCard.querySelector(".card__text");
  if (text.offsetWidth < text.scrollWidth) {
    tooltip.textContent = text.textContent;
  } else {
    tooltip.remove();
    tooltip = null;
  }
  return renderedCard;
};
const options = {
  baseUrl: "https://around.nomoreparties.co/v1/",
  apiKey: "69483cc0-2fd4-4d47-b549-ff7c13f67c88",
  groupId: "group-12",
};

const mainApi = new Api(options);
// mainApi.getProfile();
// mainApi.postNewCard(initialCards[0]);
// initialCards.forEach((card)=> mainApi.postNewCard(card));

// mainApi.getInitialCards();

// mainApi.patchPhoto('https://i.ibb.co/JzsQT1d/avatar-photo.png')

// mainApi.getProfile();

//Creates a userInfo object.
const userInfo = new UserInfo(
  ".profile__name",
  ".profile__about",
  ".profile__photo"
);
// userInfo.setUserInfo(mainApi.getProfile());
// console.log(userInfo);
mainApi.getProfile().then((res) => userInfo.setUserInfo(res));
console.log(userInfo);

// mainApi.updateProfile(userInfo.getUserInfo());
//cardRendering function passed to section class for cardSection and new card creators.
const confirmWindow = new PopupConfirm("#w-confirm");
confirmWindow.setEventListeners();

const cardRenderer = (newCard) => {
  const cardElement = new Card(
    newCard,
    cardTemplate,
    (evt) => {
      galleryPopup.open(evt);
    },
    (id) => {
      confirmWindow.open();

      confirmWindow.setFunction(() => {
        loader({
          dots: {
            interval: 100,
            count: 4,
          },
          completeTimeDelay: 250,
          callbackEnd: () => confirmWindow.close(),
          clickHandler: () =>
            mainApi.deleteCardPost(id).then(cardElement.deleteCard()),
        });
        // const button = document
        //   .querySelector(".popup_active")
        //   .querySelector(".button_type_submit");
        // const buttonValue = button.textContent.toString();
        // const buttonStateProcessing = /\w*e\b/.test(buttonValue)
        //   ? /\w*e\b/.exec(buttonValue).toString().replace(/\w\b/, "ing")
        //   : button.textContent.toString() + "ing";
        // const buttonStateComplete = /\w*e\b/.test(buttonValue)
        //   ? /\w*e\b/.exec(buttonValue).toString().replace(/\w\b/, "ed")
        //   : button.textContent.toString() + "ed";
        // const loop = () => {
        //   if (button.textContent.length > 9)
        //     button.textContent = `${buttonStateProcessing}`;
        //   else button.textContent += ".";
        // };
        // let intervalController = setInterval(loop, 100);
        // mainApi
        //   .deleteCardPost(id)
        //   .then((res) => {
        //     cardElement.deleteCard();
        //     clearInterval(intervalController);
        //     button.textContent = `${buttonStateComplete} successfully`;
        //     confirmWindow.close();
        //     setTimeout(() => {
        //       button.textContent = `${buttonValue}`;
        //     }, 300);
        //   })
        //   .catch((res) => {
        //     button.textContent = `Failed`;
        //     button.setAttribute("disabled", true);
        //     setTimeout(() => {
        //       button.textContent = `${buttonValue}`;
        //       button.removeAttribute("disabled");
        //     }, 1200);

        //     clearInterval(intervalController);
        //     console.log(res);
        //   });
      });
    },
    (id) => {
      if (cardElement.likes.some((entry) => entry._id == userInfo._data._id)) {
        mainApi.dislikePhoto(id).then((res) => cardElement._handleLike(res))
          .finally;
      } else {
        mainApi.likePhoto(id).then((res) => cardElement._handleLike(res))
          .finally;
        // cardElement;
      }
    },
    userInfo._data._id
  );
  const renderedCard = cardElement.createCard();
  return renderedCard;
};
// mainApi.getProfile();
//Creates the pop with the edit form
const editPopup = new PopupForm(editProfileWindow, () => {
  userInfo.setUserInfo(editPopup.getInputValues());
  const button = document
    .querySelector(".popup_active")
    .querySelector(".button_type_submit");

  const buttonValue = button.textContent.toString();

  const buttonStateProcessing = /\w*e\b/.test(buttonValue)
    ? /\w*e\b/.exec(buttonValue).toString().replace(/\w\b/, "ing")
    : button.textContent.toString() + "ing";

  const buttonStateComplete = /\w*e\b/.test(buttonValue)
    ? /\w*e\b/.exec(buttonValue).toString().replace(/\w\b/, "ed")
    : button.textContent.toString() + "ed";

  const loop = () => {
    if (button.textContent.length > 9)
      button.textContent = `${buttonStateProcessing}`;
    else button.textContent += ".";
  };
  let intervalController = setInterval(loop, 100);
  console.log(editPopup.getInputValues());
  mainApi
    .updateProfile(editPopup.getInputValues())
    .then(() => {
      clearInterval(intervalController);
      button.textContent = `${buttonStateComplete} successfully`;
      editPopup.close();
      setTimeout(() => {
        button.textContent = `${buttonValue}`;
      }, 300);
    })
    .catch(() => {
      clearInterval(intervalController);
    });
});

editPopup.setEventListeners();

const editPicWindow = new PopupForm(editProfilePictureWindow, () => {
  mainApi
    .updateProfilePhoto(editPicWindow.getInputValues().avatar)
    .then((res) => userInfo.setUserInfo(res))
    .then(editPicWindow.close());
});

editPicWindow.setEventListeners();
//creates popup with form corresponding to add button with a callback function;

const addPopup = new PopupForm(addWindow, () => {
  let newCard = addPopup.getInputValues();
  newCard = cardRenderer(newCard);
  cardSection.addItem(newCard);
  tooltipCheck(newCard);
  addPopup.close();
});

addPopup.setEventListeners();

//Creates the gallery popup
const galleryPopup = new PopupGallery(galleryWindow);
galleryPopup.setEventListeners();
//form Validation
const profileLarge = new PopupGallery(largeProfileImageWindow);
profileLarge.setEventListeners();
const editValidator = new FormValidator(editForm, settings);
editValidator.enableValidation();

const addValidator = new FormValidator(addForm, settings);
addValidator.enableValidation();

const editPicValidator = new FormValidator(editProfilePictureForm, settings);
editPicValidator.enableValidation();

console.log(editProfilePictureForm);
//adds card section
const cardSection = new Section(
  {
    items: initialCards,
    renderer: (newCard) => {
      newCard = cardRenderer(newCard);
      cardSection.addItem(newCard, "append");
      tooltipCheck(newCard);
    },
  },
  cardContainer
);
//renders card section
mainApi.getInitialCards().then((data) => {
  cardSection.renderItems(data);
  console.log(data);
});

//<<START>> base page button listeners <<START>>
editButton.addEventListener("click", () => {
  editPopup.setInputValues(userInfo.getUserInfo());
  editPopup.open();
}); //edit button listener
addButton.addEventListener("click", () => addPopup.open());

editImageButton.addEventListener("click", () => {
  editPicWindow.setInputValues(userInfo.getUserInfo());
  editPicWindow.open();
});

enlargeImageButton.addEventListener("click", () => profileLarge.open());

//add button listener
//<<END>> base page button listeners <<END>>
// 69483cc0-2fd4-4d47-b549-ff7c13f67c88
document
  .querySelector(".button_type_edit-profile-image")
  .addEventListener("click", function testFunction() {
    fetch("https://around.nomoreparties.co/v1/group-12/cards/", {
      headers: {
        authorization: "69483cc0-2fd4-4d47-b549-ff7c13f67c88",
      },
    })
      .then((res) => res.json())
      .then((res) => console.log(res));
  });

const obj1 = mainApi.getProfile();

const obj2 = userInfo.getUserInfo();
console.log(
  Object.keys(obj1).every(
    (key) => obj2.hasOwnProperty(key) && obj2[key] === obj1[key]
  )
);
// userInfo.setUserInfo(mainApi.getProfile());
mainApi.likePhoto(`61701145a4dfb400c4c58d21`).then((res) => console.log(res));
